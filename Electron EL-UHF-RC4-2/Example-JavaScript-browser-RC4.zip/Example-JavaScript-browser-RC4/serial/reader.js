import { toHex } from "./utils.js";
import { Response, Tag } from "./response.js";
import { Command } from "./command.js";

export class Reader {
  /**
   * @param {import('./transport.js').SerialTransport} transport
   */
  constructor(transport) {
    this.transport = transport;
  }

  async request(command) {
    await this.transport.send(command.serialize());
    console.log("Sent command:", toHex(command.serialize()));
  }

  async receive() {
    // 1) Read 5 byte: [0xCF][ADDR][CMD_0][CMD_1][LEN]
    const headerSection = await this.transport.read(5);
    if (!headerSection || headerSection.length !== 5) {
      console.error("receive(): incomplete header, got: ", headerSection);
      return null;
    }

    const [header, readerAddress, cmd0, cmd1, lenData] = headerSection;

    if (header !== 0xcf) {
      console.error(
        `receive(): invalid header (expected 0xCF, got 0x${header
          .toString(16)
          .toUpperCase()})`
      );
      return null;
    }

    if (lenData < 0 || lenData > 255) {
      console.error(`receive(): invalid length byte (${lenData})`);
      return null;
    }

    // 2) Read body
    const needBody = lenData + 2; // CRC-16 (2 byte)
    const bodySection = await this.transport.read(needBody);
    if (!bodySection || bodySection.length !== needBody) {
      this.transport.clear();
      console.error(
        `receive(): body incomplete (got ${
          bodySection?.length ?? 0
        } of ${needBody}), body: ${toHex(bodySection)}`
      );
      return null;
    }
    // 3) Combine header + body
    const frame = new Uint8Array(5 + needBody);
    frame.set(headerSection, 0);
    frame.set(bodySection, 5);

    return new Response(frame);
  }

  async stopInventoryAnswerMode() {
    const cmd = new Command([0x00, 0x02], 0xff);
    try {
      await this.request(cmd);
    } catch (e) {
      console.error("stopInventoryAnswerMode() error:", e);
      return;
    }
  }

  // stopAfter: Seconds to stop after (0 = never)
  async *inventoryAnswerMode({ stopAfter = 0 } = {}) {
    const stopAfterBytes = new Uint8Array(4);
    new DataView(stopAfterBytes.buffer).setUint32(0, stopAfter, false);

    const cmd = new Command(
      [0x00, 0x01], // Command code
      0xff, // Reader address
      new Uint8Array([0x00, ...stopAfterBytes]) // 0x00 = mode: stop after time
    );
    console.log("Starting inventoryAnswerMode()...");

    try {
      await this.request(cmd);

      let frames = 0;
      while (true) {
        const resp = await this.receive();
        if (!resp) {
          console.warn("inventoryAnswerMode(): receive() returned null.");
          continue;
        }

        if (!resp.validateChecksum()) {
          console.warn(
            "inventoryAnswerMode(): checksum invalid; clearing buffer..."
          );
          await this.transport.clear();
          frames++;
          continue;
        }

        const data = resp.data ?? new Uint8Array(0);
        const tagStatus = data[0];

        // 0x12 - No tag found during inventory, or tag inventory has finished
        if (data.length == 1) {
          if (tagStatus == 0x12) {
            console.log(
              "inventoryAnswerMode(): 0x12 (no tag / inventory finished) received."
            );
          }
          // Add more status code handling here if needed, check INVENTORY_ISO_CONTINUE status documentation
          return;
        }

        yield new Tag(data.slice(1, data.length));
      }
    } catch (e) {
      console.error("inventoryAnswerMode() error:", e);
      return;
    }
  }
}
