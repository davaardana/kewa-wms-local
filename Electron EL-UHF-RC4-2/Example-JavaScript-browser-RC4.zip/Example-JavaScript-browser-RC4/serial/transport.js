import { delay } from "./utils.js";

export class SerialTransport {
  port = null;
  reader = null;
  writer = null;

  async open({
    baudRate = 115_200,
    bufferSize = 1_024,
    dataBits = 8,
    stopBits = 1,
    parity = "none",
    flowControl = "none",
    filters,
    requestPort = true,
  } = {}) {
    if (!this.port) {
      this.port = requestPort
        ? await navigator.serial.requestPort(filters ? { filters } : undefined)
        : (await navigator.serial.getPorts())[0] ?? null;
      if (!this.port) throw new Error("No serial port");
    }

    if (!this.port.readable || !this.port.writable) {
      await this.port.open({
        baudRate,
        bufferSize,
        dataBits,
        stopBits,
        parity,
        flowControl,
      });
    }

    try {
      await this.port.setSignals?.({
        dataTerminalReady: true,
        requestToSend: true,
      });
    } catch {}
    await delay(30);

    this.reader = this.port.readable?.getReader({ mode: "byob" }) ?? null;
    this.writer = this.port.writable?.getWriter() ?? null;

    console.log("Serial opened:", this.getDeviceInfo() || "unknown device");
  }

  async close() {
    try {
      if (this.reader) {
        this.reader.releaseLock();
        this.reader = null;
      }
      if (this.writer) {
        await this.writer.close().catch(() => {});
        this.writer.releaseLock();
        this.writer = null;
      }
      if (this.port) {
        await this.port.close().catch(() => {});
      }
    } finally {
      this.port = null;
    }
  }

  getDeviceInfo() {
    if (!this.port?.getInfo) return null;
    const { usbVendorId, usbProductId } = this.port.getInfo();
    return { usbVendorId, usbProductId };
  }

  async send(data, { chunkSize = 0, interChunkMs = 0 } = {}) {
    if (!this.writer) throw new Error("Port not writable");
    if (!chunkSize || chunkSize <= 0) {
      await this.writer.write(data);
      return;
    }
    for (let off = 0; off < data.length; off += chunkSize) {
      const slice = data.subarray(off, Math.min(off + chunkSize, data.length));
      await this.writer.write(slice);
      if (interChunkMs) await delay(interChunkMs);
    }
  }

  async _receiveChunk(size) {
    if (!this.reader) throw new Error("Reader not initialized");
    if (size <= 0) return new Uint8Array(0);

    // BYOB: provide your own buffer for efficient reads
    const byob = new Uint8Array(size);
    const { value, done } = await this.reader.read(byob);
    if (done) return new Uint8Array(0);

    // `value` is a view over `byob` cropped to the actual bytes read
    return value?.byteLength === byob.byteLength ? byob : value.slice();
  }

  async read(size, { interChunkIdleMs = 20 } = {}) {
    const chunks = [];
    let received = 0;

    while (received < size) {
      // Ask only for what's still missing, cap to keep snappy
      const want = Math.min(1024, size - received);
      try {
        const chunk = await this._receiveChunk(want);
        if (chunk.byteLength === 0) {
          // No bytes this turn → brief idle, then retry
          await delay(interChunkIdleMs);
          continue;
        }
        chunks.push(chunk);
        received += chunk.byteLength;
      } catch (e) {
        console.error("receiveExact() read error:", e);
        return null;
      }
    }

    // Fast path: single chunk already complete
    if (chunks.length === 1) return chunks[0];

    // Combine chunks into a single contiguous buffer
    const out = new Uint8Array(size);
    let off = 0;
    for (const c of chunks) {
      out.set(c, off);
      off += c.byteLength;
    }
    return out;
  }

  async clear() {
    if (!this.reader) return;
    const buf = await this.read(512);
    if (!buf || buf.length === 0) console.log("No data in buffer.");
    else console.log("Buffer cleared:", buf);
  }
}
