import { calculateChecksum } from "./utils.js";

export class Command {
  /**
   * @param {Uint8Array | number[]} command
   * @param {number} [address=0xFF]
   * @param {Uint8Array | number[]} [data=[]]
   */
  constructor(command, address = 0xff, data = []) {
    if (!(command instanceof Uint8Array)) command = new Uint8Array(command);
    if (command.length !== 2) {
      throw new Error("Command must be exactly 2 bytes.");
    }

    this.command = command;
    this.address = address;
    this.data = data instanceof Uint8Array ? data : new Uint8Array(data);
  }

  /**
   * Build the binary frame.
   * @param {boolean} [withChecksum=true]
   * @returns {Uint8Array}
   */
  serialize(withChecksum = true) {
    const base = [];

    // HEADER
    base.push(0xcf);

    // ADDRESS
    base.push(this.address);

    // COMMAND (2 bytes)
    base.push(this.command[0], this.command[1]);

    // DATA LENGTH
    base.push(this.data.length);

    // DATA (optional payload)
    base.push(...this.data);

    let frame = new Uint8Array(base);

    // CHECKSUM
    if (withChecksum) {
      const checksumValue = calculateChecksum(frame);

      const checksumBytes = new Uint8Array([
        (checksumValue >> 8) & 0xff,
        checksumValue & 0xff,
      ]);

      const full = new Uint8Array(frame.length + 2);
      full.set(frame, 0);
      full.set(checksumBytes, frame.length);

      frame = full;
    }

    return frame;
  }
}
